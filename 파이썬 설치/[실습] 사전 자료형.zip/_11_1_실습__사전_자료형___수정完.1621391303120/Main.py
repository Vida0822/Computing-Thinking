# -*- coding: utf-8 -*-
# UTF-8 encoding when using korean

phones= {"model": "iphone11", "manufacturer": "Apple", 'year':'2019'}
#" ", ' ' 여부는 상관 없음 (일치 시킬필요 ㄴㄴ 그래도 왠만하면 하기)
print(phones["year"])

print(phones.clear())